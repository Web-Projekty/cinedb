<?php
//Redirection - přesměrování
header("Location: final/");
