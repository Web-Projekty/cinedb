<footer>
    <div class="footer-text">
        <p>2. ročníková práce</p>
        <p>Vytvořil Pták, Vlček, Rehák</p>
        <p><?php echo date("d/m/Y") ?></p>
    </div>
</footer>