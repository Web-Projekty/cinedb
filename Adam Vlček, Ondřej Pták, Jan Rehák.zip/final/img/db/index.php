<?php
//Redirection
header("Location: ../../");
