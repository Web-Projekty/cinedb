Složka pro finální verzi webového projektu CineDB.

Pro vyzkoušení administrátorských funkcí je potřeba přihlášení skrz administrátorský účet!!
uživatelské jméno: admin
heslo: 12345678