<?php
//Redirection
header("Location: ../");
