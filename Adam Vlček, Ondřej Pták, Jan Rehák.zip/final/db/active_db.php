<?php //zde bude aktivní připojení pro SQL databázi
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cineDB";
