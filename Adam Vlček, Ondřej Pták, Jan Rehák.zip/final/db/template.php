<?php //Zde budou předpřipravené konfigurace
//local
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cineDB";
//vlastas.co
$servername = "localhost:3306";
$username = "cineDB";
$password = "#BDenic2305";
$dbname = "cineDB";
