<?php //nechce se mi vytvářet novou databázi pro typy seriálů/filmů, takže budou tady v poli $typy ☺
$typy = ["TV", "Movie", "OVA", "ONA", "Special"];
